# Xmoon visual update

- Added a subtle, animated black background with floating white SF Symbols.
- The animation pauses while the Settings sheet is open.
- Removed the tappable app identity row that opened the original GitHub repository.
- Removed external GitHub profile taps and remote profile-image loading from Credits.
- Preserved the textual contributor attribution and AGPL-3.0 license notice.

The new SwiftUI background file is included automatically by the project's synchronized `mond` source group.
