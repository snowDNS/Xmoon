//
//  ContentView.swift
//  mond
//
//  Created by ruter on 17.07.26.
//

import SwiftUI
import PartyUI

struct ContentView: View {
    @EnvironmentObject var state: AppState
    @AppStorage("ignore_failure") private var ignore_failure = false
    
    @State private var is_valid: Bool = false
    @State private var show_settings: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                FloatingSymbolsBackground(isActive: !show_settings)

                List {
                Section {
                    LogView()
                        .modifier(TerminalPlatter())
                } header: {
                    Label("Logs", systemImage: "apple.terminal")
                }
                
                Section {
                    NavigationLink {
                        GestaltView()
                    } label: {
                        HStack {
                            Text("MobileGestalt")
                            if state.granting_mg {
                                Spacer()
                                ProgressView()
                                    .tint(Color.primary)
                            }
                        }
                    }
                    .disabled((state.mg_granted != true) && !ignore_failure)
                    
                    NavigationLink {
                        PosterView()
                    } label: {
                        HStack {
                            Text("PosterBoard")
                            if state.granting_pb {
                                Spacer()
                                ProgressView()
                                    .tint(Color.primary)
                            }
                        }
                    }
                    .disabled((state.pb_granted != true) && !ignore_failure)
                    
                    NavigationLink {
                        SantanderView()
                    } label: {
                        HStack {
                            Text("HouseArrest")
                            if state.granting_apps {
                                Spacer()
                                ProgressView()
                                    .tint(Color.primary)
                            }
                        }
                    }
                    .disabled((state.apps_granted != true) && !ignore_failure)
                } header: {
                    Label("Tweaks", systemImage: "paintbrush")
                }
                
                Section {
                    NavigationLink {
                        CEView()
                    } label: {
                        Text("CacheExtra Fields")
                    }
                } header: {
                    Label("Advanced", systemImage: "wrench.and.screwdriver")
                } footer: {
                    Text("Only use these Tweaks if you know what you're doing.\nYou could break something irreversibly.")
                }
            }
            .scrollContentBackground(.hidden)
            .listRowBackground(Color.white.opacity(0.035))
            .background(Color.clear)
            .navigationTitle("Xmoon")
            .tint(Color("AccentColor"))
            .preferredColorScheme(.dark)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack {
                        Button {
                            show_settings = true
                        } label: {
                            Image(systemName: "gear")
                        }
                    }
                }
            }
            .sheet(isPresented: $show_settings) {
                SettingsView()
            }
            }
        }
    }
}
