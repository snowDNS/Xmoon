//
//  FloatingSymbolsBackground.swift
//  Xmoon
//
//  A lightweight monochrome animated background for the main screen.
//

import SwiftUI

private struct FloatingSymbol: Identifiable {
    let id: Int
    let name: String
    let x: CGFloat
    let y: CGFloat
    let size: CGFloat
    let opacity: Double
    let speed: Double
    let phase: Double
    let driftX: CGFloat
    let driftY: CGFloat
}

struct FloatingSymbolsBackground: View {
    var isActive: Bool = true

    private let symbols: [FloatingSymbol] = [
        .init(id: 0, name: "apple.logo", x: 0.12, y: 0.14, size: 25, opacity: 0.24, speed: 0.34, phase: 0.2, driftX: 0.035, driftY: 0.025),
        .init(id: 1, name: "sparkles", x: 0.78, y: 0.13, size: 22, opacity: 0.28, speed: 0.27, phase: 1.1, driftX: 0.045, driftY: 0.035),
        .init(id: 2, name: "moon.stars.fill", x: 0.88, y: 0.34, size: 27, opacity: 0.20, speed: 0.22, phase: 2.4, driftX: 0.025, driftY: 0.045),
        .init(id: 3, name: "iphone", x: 0.18, y: 0.42, size: 23, opacity: 0.22, speed: 0.31, phase: 3.0, driftX: 0.04, driftY: 0.03),
        .init(id: 4, name: "gearshape.fill", x: 0.68, y: 0.55, size: 20, opacity: 0.16, speed: 0.25, phase: 0.8, driftX: 0.035, driftY: 0.04),
        .init(id: 5, name: "apple.logo", x: 0.38, y: 0.68, size: 29, opacity: 0.19, speed: 0.19, phase: 4.1, driftX: 0.05, driftY: 0.025),
        .init(id: 6, name: "wifi", x: 0.91, y: 0.78, size: 24, opacity: 0.22, speed: 0.29, phase: 1.7, driftX: 0.03, driftY: 0.035),
        .init(id: 7, name: "bolt.fill", x: 0.11, y: 0.86, size: 20, opacity: 0.18, speed: 0.36, phase: 2.9, driftX: 0.04, driftY: 0.025),
        .init(id: 8, name: "circle.hexagongrid.fill", x: 0.52, y: 0.28, size: 19, opacity: 0.14, speed: 0.23, phase: 5.2, driftX: 0.03, driftY: 0.04),
        .init(id: 9, name: "waveform", x: 0.54, y: 0.91, size: 24, opacity: 0.17, speed: 0.28, phase: 3.7, driftX: 0.05, driftY: 0.02)
    ]

    var body: some View {
        GeometryReader { geometry in
            TimelineView(.animation(minimumInterval: 1.0 / 24.0, paused: !isActive)) { timeline in
                let time = timeline.date.timeIntervalSinceReferenceDate

                ZStack {
                    Color.black

                    ForEach(symbols) { symbol in
                        let dx = sin(time * symbol.speed + symbol.phase) * symbol.driftX
                        let dy = cos(time * symbol.speed * 0.83 + symbol.phase) * symbol.driftY
                        let x = min(max(symbol.x + dx, 0.06), 0.94) * geometry.size.width
                        let y = min(max(symbol.y + dy, 0.06), 0.94) * geometry.size.height

                        Image(systemName: symbol.name)
                            .font(.system(size: symbol.size, weight: .light))
                            .foregroundStyle(.white.opacity(symbol.opacity))
                            .position(x: x, y: y)
                    }
                }
                .frame(width: geometry.size.width, height: geometry.size.height)
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}
